export SFDX_REST_DEPLOY=false

# packaging
devhub@tagit.labapp/kam***8
pkg@tagit.labapp
test@tagit.app

"ancestorVersion": "4.6.0.1"

https://github.com/kamipatel/TagItApp

sfdx force:auth:web:login -d -a "tagit-devhub"

sfdx force:org:create -s -f config/project-scratch-def.json -a "TagitApp" -u "tagit-devhub" -d 30

sfdx force:source:push -u "TagitApp"

sfdx force:user:permset:assign --permsetname TagitPerms -u "TagitApp" 

sfdx force:org:open -u "TagitApp"

sfdx force:source:pull -u "TagitApp"

sfdx analytics:app:list -u TagitApp 

sfdx analytics:template:create -f "00lJ0000000ygI3IAI" --loglevel debug  -u TagitApp 

sfdx analytics:template:update -f "00lJ0000000ygI3IAI" -t "0NkJ00000004EwaKAE" --loglevel debug  -u TagitApp 

sfdx analytics:template:list -u TagitApp 

#### Apex test
sfdx force:apex:test:run --synchronous --resultformat tap --codecoverage -r human  -u "TagitApp"

#### Run LWC locally
sfdx force:lightning:lwc:start -u "TagitApp"

#### Package creation
sfdx force:package:create --name "TagIt App" --packagetype Managed  --targetdevhubusername "tagit-devhub" --path force-app
0333h000000HNlVAAW

# PackageId: 0Ho3h0000004CAQCA2
# sfdx force:package:version:create -p "TagIt App" -x -c --wait 10 -v "tagit-devhub" --loglevel DEBUG /packaging/installPackage.apexp?p0=04t3h000004Yr2DAAS

sfdx force:package:version:create --package "TagIt App" --installationkeybypass --definitionfile config/project-scratch-def.json --wait 10 --codecoverage 
https://login.salesforce.com/packaging/installPackage.apexp?p0=04t3h0000045tjjAAA

sfdx force:package:version:promote -p "TagIt App@9.1.0-0" -n --targetdevhubusername "tagit-devhub"


# dev
sfdx force:auth:web:login -d -a LWC-Hub
kamlesh.patel-epje@force.com/kam123456

sfdx force:org:create -s -f config/project-scratch-def.json -a "Tag" -d 30

sfdx force:user:password:generate --targetusername test-fv9feb421ek9@example.com

https://test.salesforce.com
test-fv9feb421ek9@example.com
ZN0(qNf0X1

https://data-velocity-2777-dev-ed.cs26.my.salesforce.com
kamlesh.patel@salesforce.com/kam12345678

SELECT RecordId, HasEditAccess FROM UserRecordAccess where  UserId ='005210000044pVYAAY' AND RecordId='0012100000oWBgjAAG'

sfdx force:org:open

sfdx force:source:pull

sfdx force:source:push

sfdx force:source:deploy -p ./force-app/main/default/staticresources 

# delete metadata
sfdx force:data:soql:query -q "Select Id, MemberName From SourceMember Where MemberType = 'CustomApplication'" -t

sfdx force:data:record:delete -s SourceMember -i 0MZR0000007PiSgOAK -t