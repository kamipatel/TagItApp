import { LightningElement } from 'lwc';

export default class PageTrackerCmp extends LightningElement {}